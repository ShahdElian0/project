﻿using System;
using System.Collections.Generic;

int a , b , c , d ;

a = 25;b = 25;

Console.WriteLine($"{a}+{b}={AddNumber(a,b)}");
DisplayMessageAfterProcess(" shahad");


c = 30;d = 72;

Console.WriteLine($"{c}+{d}={AddNumber(c,d)}");
DisplayMessageAfterProcess(" shahd");

static int AddNumber(int a, int b)
{
    return a + b;
}
static void DisplayMessageAfterProcess(string userName)
{
    Console.WriteLine($"process is done by{ userName}");
}
Console.ReadLine();